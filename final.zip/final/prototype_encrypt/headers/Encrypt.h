#ifndef ENCRYPT_H
#define ENCRYPT_H

#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <sstream>
#include <sodium.h>

class Encrypt{

 public:

  Encrypt( std::string, std::string, std::string);
  
  int messagesize;
  unsigned char publickey[crypto_box_PUBLICKEYBYTES];
  unsigned char secretkey[crypto_box_SECRETKEYBYTES];

  //initialises public and private keys from files at path in args, first argument is the path
  //to the publickey of the recipient second is to the private key belonging to the sender
  bool getKeysFromPath(std::string, std::string);
  
 private:

  void encryptMessage(std::string);
  
};

#endif
