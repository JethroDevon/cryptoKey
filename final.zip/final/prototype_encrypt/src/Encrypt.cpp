#include "../headers/Encrypt.h"

Encrypt::Encrypt( std::string path_to_pubkey, std::string path_to_seckey,  std::string plaintext){

  if( getKeysFromPath( path_to_pubkey, path_to_seckey)){

    encryptMessage( plaintext);
  }
}

//takes plaintext as an argument and returns cipher text as a string
void Encrypt::encryptMessage( std::string _plaintext){

  unsigned long long message_length = _plaintext.size();
  unsigned long long ciphertext_length = crypto_box_MACBYTES + message_length; 
  unsigned char nonce[crypto_box_NONCEBYTES];
  randombytes_buf(nonce, sizeof nonce);

  //std::cout<< "length of message: " << ciphertext_length << " characters" <<std::endl;
  
  for (int n = 0; n < crypto_box_NONCEBYTES; n++) {

   printf("%u",(unsigned int)nonce[n]);
   std::cout<< "-";
  }
  
  unsigned char ciphertext[ciphertext_length];
  
  //call sodiums encryption function
  if (crypto_box_easy( ciphertext, (const unsigned char *)_plaintext.c_str(),
		       message_length, nonce, publickey, secretkey) != 0){

    std::cout<< "could not encrypt message" <<std::endl;
  }

  //convert output to a binary file line by line, sending ciphersize first
  //followed by cipher then nonce all seperated by lines to make unwrapping easier
  std::ofstream out( "encrypted.bin", std::ios::binary);
  
  out.write(reinterpret_cast<char*>(&ciphertext_length), sizeof(ciphertext_length));
  out.write(reinterpret_cast<char*>(&ciphertext), ciphertext_length);
  out.write(reinterpret_cast<char*>(&nonce), crypto_box_NONCEBYTES);
  out.close();
}

///create a function that encrypts and decrypts a binary file

//files for senders private key and recipients public key are found at paths
//in arguments
bool Encrypt::getKeysFromPath( std::string _path_pub, std::string _path_sec){

  //create and open streams then error check
  std::ifstream inpub, insec; 
  inpub.open ( _path_pub, std::ios::binary);
  insec.open ( _path_sec, std::ios::binary);
				
  if(inpub.fail() || insec.fail()){
    
    std::cout<< "failed, Possible that a path or file is not valid" <<std::endl;
    return false;
  }

  ///alter code to use just one vector 
  std::vector<unsigned char> pubbytes;
  std::vector<unsigned char> secbytes;

  //reads *pub.bin at path location then initialises publickey variable in a for loop
  pubbytes.resize(32);
  inpub.read( (char*)( &pubbytes[0]), 32);
  inpub.close();
  
  for (int i = 0; i < pubbytes.size(); i++) {

    publickey[i] = pubbytes[i];
  }

  //reads *sec.bin at path location then initialises secretkey variable in a for loop
  secbytes.resize(32);
  insec.read( (char*)( &secbytes[0]), 32);
  insec.close();
 
  for (int i = 0; i < secbytes.size(); i++) {

    secretkey[i] = secbytes[i];
  }

  std::cout<< "\nimported keys"<<std::endl;
  return true;
}
