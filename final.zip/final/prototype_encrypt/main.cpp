#include "./headers/Encrypt.h"
#include <string>

int main(int argc, char *argv[]){

  if (argc != 4) {

    std::cout<< "Three arguments required, Path to publickey of recipient, secretkey and path to file to encrypt" <<std::endl;
  }else{

    Encrypt encrypt( argv[1], argv[2], argv[3]);
  }
}
