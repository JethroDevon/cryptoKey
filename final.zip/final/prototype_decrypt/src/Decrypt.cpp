#include "../headers/Decrypt.h"

Decrypt::Decrypt( std::string path_to_pubkey, std::string path_to_seckey,  std::string path_to_encrypted_file){

  if( getKeysFromPath( path_to_pubkey, path_to_seckey)){

    decryptMessage(path_to_encrypted_file);
  }
}

//takes plaintext as an argument and returns cipher text as a string
void Decrypt::decryptMessage( std::string _ciphertext_file){

  //create file streams and check if they are succefully opened
  std::ifstream in ( _ciphertext_file, std::ios::in | std::ios::binary);
  std::ofstream out( "decrypted.bin", std::ios::binary);
  
  if(in.fail() || out.fail()){
    
    std::cout<< "failed, Possible that a path or file is not valid" <<std::endl;
  }

  unsigned long long messagelen = 0;
  std::vector<unsigned char> cipherbytes;
  std::vector<unsigned char> noncebytes;

  in.read( (char*)( &messagelen), sizeof(messagelen)); 
  
  cipherbytes.resize(messagelen * sizeof(unsigned char));
  in.read( (char*)( &cipherbytes[0]), );
  
  unsigned char ciphertext[messagelen];
  for (int i = 0; i < messagelen; i++) {

    ciphertext[i] = cipherbytes[i];
    std::cout<< ciphertext[i];
  }
  
  unsigned char nonce[crypto_box_NONCEBYTES];
  noncebytes.resize(crypto_box_NONCEBYTES);
  in.read( (char*)( &noncebytes[0]), crypto_box_NONCEBYTES);

  for (int i = 0; i < crypto_box_NONCEBYTES; i++) {

    nonce[i] = noncebytes[i];
  }

  in.close();
  
  unsigned char plaintext[messagelen - 16];
   
  //call sodiums decryption function
  if (crypto_box_open_easy( plaintext, ciphertext,
			    messagelen, nonce, publickey, secretkey) != 0){

    std::cout << "Decryption is suspect, message is not reliable" << std::endl;
  }else{

    std::cout<< "Decryption successful" <<std::endl;
  }

  out.close();
}

///create a function that encrypts and decrypts all kinds of binary file

//files for senders private key and recipients public key are found at paths
//in arguments
bool Decrypt::getKeysFromPath( std::string _path_pub, std::string _path_sec){

  //create and open streams then error check
  std::ifstream inpub, insec; 
  inpub.open ( _path_pub, std::ios::binary);
  insec.open ( _path_sec, std::ios::binary);
				
  if(inpub.fail() || insec.fail()){
    
    std::cout<< "failed, Possible that a path or file is not valid" <<std::endl;
    return false;
  }

  ///alter code to use just one vector 
  std::vector<unsigned char> pubbytes;
  std::vector<unsigned char> secbytes;

  //reads *pub.bin at path location then initialises publickey variable in a for loop
  pubbytes.resize(32);
  inpub.read( (char*)( &pubbytes[0]), 32);
  inpub.close();
  
  for (int i = 0; i < pubbytes.size(); i++) {

    publickey[i] = pubbytes[i];
  }

  //reads *sec.bin at path location then initialises secretkey variable in a for loop
  secbytes.resize(32);
  insec.read( (char*)( &secbytes[0]), 32);
  insec.close();
 
  for (int i = 0; i < secbytes.size(); i++) {

    secretkey[i] = secbytes[i];
  }

  std::cout<< "\nimported keys"<<std::endl;
  return true;
}
