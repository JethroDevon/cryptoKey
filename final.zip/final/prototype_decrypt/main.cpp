#include "./headers/Decrypt.h"
#include <string>

int main(int argc, char *argv[]){

  if (argc != 4) {

    std::cout<< "Three arguments required, Path to recipients publickey, Path to own secretkey and path to file to decrypt" <<std::endl;
  }else{

    Decrypt decrypt( argv[1], argv[2], argv[3]);
  }
}
