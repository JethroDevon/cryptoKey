#ifndef ENCRYPT_H
#define ENCRYPT_H

#include <sodium.h>
#include <iostream>
#include <string>
#include <fstream>

class Keygen{ 
public:

  Keygen(std::string);
  std::string name;
  
  unsigned char publickey[crypto_box_PUBLICKEYBYTES];
  unsigned char secretkey[crypto_box_SECRETKEYBYTES];
   
 private:

  bool initialised();
  void genKeys();
  void makeKeys();
};
#endif
