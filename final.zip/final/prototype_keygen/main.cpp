#include <stdio.h>
#include "./headers/Keygen.h"

int main( int argc, const char* argv[] ){

  if ( argc != 2) {

    std::cout<< "use one argument for the keypair name" <<std::endl;
  }else{

    Keygen gen( argv[1]);
  }
}




