#include "../headers/Keygen.h"

Keygen::Keygen( std::string _name): name( _name){

  if (initialised()) {
   
    std::cout<< "libsodium is initialised"<< std::endl;
    makeKeys();
  }
}

bool Keygen::initialised(){

  if (sodium_init() == -1) {

    return false;
  }else{

    return true;
  }
}

void Keygen::makeKeys(){

  crypto_box_keypair( publickey, secretkey);

  std::ofstream outp( name + "pub.bin", std::ios::binary);

  for (int i = 0; i < sizeof(publickey); i++) {

    outp << publickey[i];
  }

  outp.close();

  std::ofstream outs( name + "sec.bin", std::ios::binary);

   for (int i = 0; i < sizeof(secretkey); i++) {

     outs << secretkey[i]<<std::endl;
  }
  
  outs.close();

  std::cout<< "keys generated" <<std::endl;
}
