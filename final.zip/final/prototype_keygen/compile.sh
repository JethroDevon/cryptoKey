g++ -std=c++11 main.cpp ./src/*.cpp -I./include -lsodium -o keygen

