#include "./headers/Streams.h"

int main(int argc, char *argv[]){
  
  Streams practice( argv[1], argv[2]):
}
