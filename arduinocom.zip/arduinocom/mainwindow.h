#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QString>
#include <string>
#include <QList>
#include <QMainWindow>
#include <QtSerialPort>
#include <QSerialPortInfo>
#include <QPushButton>
#include <QFile>
#include <QFileInfo>
#include <sodium.h>
#include <iostream>

/********************************************************************

This program is designed to debug and test the code written on the teensy
and also to help plan the finished host application.

*********************************************************************/

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow{

    Q_OBJECT

public:

    //if variables based on protocol data for an incoming cipher text
    //have all been initialised this will be true
    bool cipherflag = false;
    bool authflag = false;

    //following variables store data based on an a cipher that is expected
    QString recipientname;
    uint16_t messagesize;
    unsigned char nonce[12];
    uint16_t cipherdata_size;

    //cipherdata sends two bytes to be used in auth data and to make one 16bit
    //integer, it is cheaper to store them than it is to extract them from it
    //authdata will store data from the cipherdata header as it comes in over
    //serial connection and the auth tag is sent after that but before the cipher text
    uint8_t authbytes[2];
    QByteArray authdata;
    int authdata_size;
    unsigned char tag[16];

    //qt specific functionality
    explicit MainWindow(QWidget *parent = 0);

    //scan usb ports for teensy
    QString ScanSerialPorts();

    //read and write to files as well as parse a key from local file
    QByteArray readBinary(QString);
    void writeBinary( QString, unsigned char*);
    void SerialSendKey( QString);

    //returns a key at localpath with same name
    QByteArray getKey( QString);

    //initialises an array passed into args with a session key based on
    //recieved cipher data
    void createSessionKey( unsigned char*);

    //initialises encryption libraries and array data on startup
    bool initEncryption();
    void serialEncrypt( QString);
    void sendData( QString, unsigned char*, int);
    ~MainWindow();

    QSerialPort *serial;
    QString location;
    unsigned char publickey[32];

private slots:

    void SerialRecieved();
    void SerialSend();
    void ExchangeKeys();

private:

    Ui::MainWindow *ui;
    QPushButton *m_button;
    QPushButton *e_button;
    QPushButton *t_button;
    QPushButton *d_button;
    unsigned char secretkey[32];
};

#endif // MAINWINDOW_H
