#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :

    QMainWindow(parent),
    ui(new Ui::MainWindow){

    if(!initEncryption()){

        ui->label->append("Encryption failed\r\n");
    }

    //sets up QTs user interface system
    ui->setupUi(this);

    //initialises QTs serial port
    serial = new QSerialPort(this);

    //create, and initialise buttons
    m_button = new QPushButton("Send", this);
    m_button->setGeometry(QRect( QPoint( 170,200),QSize(60,30)));
    e_button = new QPushButton("Swap Keys", this);
    e_button->setGeometry(QRect( QPoint( 90,200),QSize(70,30)));
    t_button = new QPushButton("Swap Keys", this);
    t_button->setGeometry(QRect( QPoint( 90,200),QSize(70,30)));
    d_button = new QPushButton("Swap Keys", this);
    d_button->setGeometry(QRect( QPoint( 90,200),QSize(70,30)));

    serial->setPortName(ScanSerialPorts());
    serial->setBaudRate(QSerialPort::Baud9600);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->open(QIODevice::ReadWrite);
    connect( serial, SIGNAL(readyRead()), this, SLOT(SerialRecieved()));
    connect( m_button, SIGNAL (released()),this, SLOT (SerialSend()));
    connect( e_button, SIGNAL (released()),this, SLOT (ExchangeKeys()));
}

MainWindow::~MainWindow(){

    delete ui;
    serial->close();
}

void MainWindow::SerialSend(){

    QString message = ui->textEdit->toPlainText();
    serial->write( message.toStdString().c_str(), message.size());
    qDebug()<<"sending" << message;
}

//sends public key to dongle with username
void MainWindow::SerialSendKey( QString usernm){

    //send the command to add following data to dongles database
    serial->write("<add><", 6);
    serial->write( usernm.toStdString().c_str(), usernm.size());
    serial->write( "-");
    serial->write((char*)publickey, 32);
    serial->write(">");
}

void MainWindow::SerialRecieved(){

    //get data incoming to serial
    QByteArray qba;
    qba=serial->readAll();
    ui->label->setText(qba);
    qDebug()<< "Recieved:" << qba;


    //deal with incoming serial data if data contains specific headers
    //each block should have a try catch statment built into it
    //if pong has been recieved from serial
    if( qba == "pong"){

        ui->label->setText("pong recieved");
        qDebug()<<"pong recieved";


        //if the header publickey is recieved then process following public key
    }else if(qba.mid(0,11) == "<publickey>"){

        //convert the incoming array to unsinged char
        QByteArray qteensypub = qba.mid( 12, 32);
        unsigned char teensykey[32];
        memmove( teensykey, qteensypub, 32);

        //save the public key as teensypub
        writeBinary( "teensyduino", teensykey);

        //send public key to dongle, it will store it if it does not
        //allready have it
        SerialSendKey("QT_app");

        ui->label->setText("public key recieved from device");
        qDebug()<<"public key recieved from device";


    //if the header ciphertext is recieved process the following cipher and tag
    }else if(qba.mid(0,12) == "<cipherdata>"){

        //get the size of the cipherdata
        cipherdata_size = qba.size();

        //name follows header and is the only resizable string recieved
        //therefore it will be between the indexes 13 and 31
        recipientname = (QString)qba.mid( 13, (cipherdata_size - 31));

        //convert qbyte array into a uint8_t array as it was when it was sent
        uint8_t charcdata[ cipherdata_size];
        memmove( charcdata, qba, cipherdata_size);

        //store bytes to use later in authdata and to make up one byte
        authbytes[0] = charcdata[cipherdata_size - 5];
        authbytes[1] = charcdata[cipherdata_size - 4];

        //build a uint16_t out of two uint8_t so as to build a larger number
        messagesize = authbytes[0] | authbytes[1] << 8;

        //the nonce will 12 bytes long and start after the recipients name
        memmove( nonce, qba.mid( 13 + recipientname.size()), 12);

        //create the authdata to pass into decryption algorithms args
        authdata_size = recipientname.size() + 15;
        authdata = qba.mid( 13, authdata_size);

        //all cipher data has been sent and auth data can be constructed
        cipherflag = true;
        qDebug()<< "cipher data obtained";


    //the following block works once the auth data has been collected, the functin
    //generates a session key and parses out the cipher text from the byte array
    //then decrypts the text.
    }else if(qba.mid(0,10) == "<authdata>"){

        //parse the auth tag
        QByteArray qtag = qba.mid( 11, 27);
        memmove( tag, qtag, 16);

        authflag = true;
        qDebug()<< "auth data obtained";


    //when the actual cipher text comes then the cipher data and auth data
    //should have been obtained, this block uses the data to decrypt the message
    }else if(qba.mid(0,12) == "<ciphertext>"){

        //create a session key and initialise it
        unsigned char key[32];
        createSessionKey(key);

        //parse ciphertext from the string and set the correct size
        QByteArray qcipher = qba.mid( 13, messagesize);
        unsigned char cipher[messagesize];
        memmove( cipher, qcipher, messagesize);

        //also parse the auth data stored in the qbyte array
        unsigned char _auth[authdata_size];
        memmove( _auth, authdata, authdata_size);

        //create a variable to store the decrypted text and its size
        unsigned char decrypted[messagesize];

        //decrypt the text
        if (messagesize == 0 || !authflag || crypto_aead_aes256gcm_decrypt_detached(
                    decrypted, NULL, cipher, (unsigned long long)messagesize,
                    tag, _auth, authdata_size, nonce, key) == -1) {

            ui->label->setText("message failed integrity check");
            qDebug()<< "-message failed integrity check-";

        }else{


            qDebug()<< "success :D";
            for(int x = 0; x < messagesize; x++){

                qDebug()<<(char)decrypted[x];
            }
        }
    }
    serial->flush();
}

/*/encrypts plaintext and sends via serial
void MainWindow::serialEncrypt( QString plaintext){

    unsigned long long mlength = plaintext.length();
    unsigned char message[mlength];
    memcpy( message, plaintext, mlength);
    unsigned char cipher[mlength];
    unsigned char nonce[12];
    unsigned char tag[16];
    unsigned char add[28];
    randombytes_buf(nonce, sizeof nonce);

    //create a session key and initialise it
    unsigned char key[32];
    createSessionKey(key);

    if(crypto_aead_aes256gcm_encrypt_detached( cipher, tag, (unsigned long long)16, message, mlength, add, (unsigned long long)28, nonce, key) == 1){

        //send additional data and cipher text to fit the dongles decryption protocol
        //that is: -recipient- then -authdata- (nonce then tag) and finaly -cipherdata- ( the ciphertext follows)
        //and finally sending -cipherdata-end- will finish the process
        serial->write("-recipient-QT_app");

        //sends authdata followed by cipherdata
        sendData( "-authdata-", add, 28);
        sendData( "-cipherdata-", cipher, mlength);
        //completes protocol
        serial->write("-cipherdata-end-");

    }else{

          qDebug()<<"encryption failed";
    }
}*/

//sends a header in args1 followed by an unsigned char array in args2 and its size in args3
void MainWindow::sendData( QString header, unsigned char* array, int data_size){

    serial->write(header.toStdString().c_str());
    for(int x = 0; x < data_size; x++){

        serial->write((char*)array[x]);
    }
}

//encrypt a file for sending to another party

//decrypt a file sent by another party

//create a public key to be used by the recipient

//sends command to exchange keys between dongle and host app
void MainWindow::ExchangeKeys(){

    serial->write("<get><localkey>");
}

//returns a session key to args if cipher data has been recieved
void MainWindow::createSessionKey( unsigned char* key){

    if( cipherflag){

        //get the teensies public key
        QByteArray qteensykey = getKey( recipientname);
        unsigned char teensykey[32];
        memmove( teensykey, qteensykey, 32);

        //use the keys to generate a shared secret key
        unsigned char sharedsecret [crypto_scalarmult_BYTES];

        if(crypto_scalarmult( sharedsecret, secretkey, teensykey) != 0){

            ui->label->setText("unable to create a shared key");
            qDebug()<< "-unable to create a shared key-";
        }else{

            qDebug()<< "shared secret generated";
        }

        //use BLAKE2b to hash the generated secret key
      //  unsigned char key[crypto_generichash_blake2b_BYTES];
      //  crypto_generichash_state state;
      //  crypto_generichash_init(&state, sharedsecret, 32, 32);
      //  crypto_generichash_update(&state, teensykey, 32);
      //  crypto_generichash_update(&state, publickey, 32);
      //  crypto_generichash_final(&state, sharedsecret, 32);

        //copy key data to pointer in args
        memmove( key, sharedsecret, 32);
    }
}


//QString is for text only!!! loook at your other shit you done this
bool MainWindow::initEncryption(){

    //get public to key generate a shared secret
    //if it doesnt exist otherwise read it from file
    if(QFileInfo("secretkey").exists() && QFileInfo("publickey").exists()){

        QByteArray qpublickey = getKey("publickey");
        QByteArray qsecretkey = getKey("secretkey");
        memmove( publickey, qpublickey, 32);
        memmove( secretkey, qsecretkey, 32);

    }else{

        randombytes_buf( secretkey, sizeof(secretkey));
        crypto_scalarmult_base( publickey, secretkey);
        writeBinary( "publickey", publickey);
        writeBinary("secretkey",  secretkey);
        QByteArray qpublickey = getKey("publickey");
        QByteArray qsecretkey = getKey("secretkey");
        memmove( publickey, qpublickey, 32);
        memmove( secretkey, qsecretkey, 32);
        qDebug()<<"keys created";
    }

    //initialise sodium libraries
    if (sodium_init() == -1) {

        return false;
    }else{

        return true;
    }
}

//finds the port that the teensyduino is on and returns its name
QString MainWindow::ScanSerialPorts(){

    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){

        if(serialPortInfo.manufacturer() == "Teensyduino"){

            location = serialPortInfo.systemLocation();
            qDebug()<<"Teensy found at " + location;
            break;
        }
    }

    return location;
}

//gets the key in args as a QByteArray, could simply return
//last 32 bits however this function will be augmented over time
QByteArray MainWindow::getKey( QString key){

    //get the file at args
    QByteArray qbuff = readBinary(key);

    //the following block of code detects the starting position of
    //the keyfile with the same heading as in the first args
    bool com_flag = false;
    bool found = false;
    QString command;
    QChar in;
    int location = 0;

    //there should be no key that is greater than 200 use this to break out
    //the loop and detect a failure to find for the next chunk of logic
    while(!found || location > 200){

        in = qbuff.at(location);

        if( in == '<')
            com_flag = true;

        if(com_flag)
            command.append(in);

        if(in == '>' && com_flag){
            if( command == ("<" + key+ ">")){

                qDebug()<< key << " found";
                location+=1;
                found = true;
                break;
            }else{

                command = "";
                com_flag = false;

            }
        }

        location++;
    }

    //returns key, debug should say key found also
    return qbuff.right(32);
}

//this function will read a file in the
QByteArray MainWindow::readBinary(QString name){

    QFile file(name);

    if(!file.open(QFile::ReadOnly)){

        qDebug()<<"open failed";
        return NULL;
    }else{

        QByteArray contents = file.readAll();
        return contents;
    }
}

//this function will write data to a binary file, the second
//argument is the heading that the data in the third aguments
//will go under, I may adapt this.
void MainWindow::writeBinary( QString name, unsigned char _keyf[32]){

    QFile file(name);

    if(!file.open( QFile::WriteOnly)){

        qDebug()<<"file not opened";
    }else{

        //this block creates an unsigned char array to store the heading name and the data
        //then writes it to the file
        QString heading = "<" + name + "><";
        int heading_size = heading.size();
        int data_size = heading_size + 32;
        unsigned char keyf[ data_size];
        for(int x = 0; x < data_size; x++){

            if(x < heading_size){

                QChar in = heading.at(x);
                keyf[x] = in.toLatin1();
            }else{

                keyf[x] = _keyf[ x - heading_size];
            }
        }
        file.write( (char*)keyf, data_size);
        file.flush();
        file.close();
    }
}
